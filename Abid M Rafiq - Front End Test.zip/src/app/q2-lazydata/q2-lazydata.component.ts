import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-q2-lazydata',
  templateUrl: './q2-lazydata.component.html',
  styleUrls: ['./q2-lazydata.component.sass']
})
export class Q2LazydataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
