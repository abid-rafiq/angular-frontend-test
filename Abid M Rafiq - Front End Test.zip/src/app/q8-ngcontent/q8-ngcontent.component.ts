import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-q8-ngcontent',
  templateUrl: './q8-ngcontent.component.html',
  styleUrls: ['./q8-ngcontent.component.sass']
})
export class Q8NgcontentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
