import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-q2-lazydata2',
  templateUrl: './q2-lazydata2.component.html',
  styleUrls: ['./q2-lazydata2.component.sass']
})
export class Q2Lazydata2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
